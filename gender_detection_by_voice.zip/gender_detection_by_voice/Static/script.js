let audioContext;
let mediaStream;
let recorder;
let audioData = [];

const recordBtn = document.getElementById("record");
const stopBtn = document.getElementById("stop");

recordBtn.onclick = async () => {
    audioData = [];
    recordBtn.disabled = true;
    stopBtn.disabled = false;
    document.getElementById("status").innerText = "Recording...";

    audioContext = new (window.AudioContext || window.webkitAudioContext)();
    mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });

    const input = audioContext.createMediaStreamSource(mediaStream);
    recorder = audioContext.createScriptProcessor(4096, 1, 1);

    recorder.onaudioprocess = e => {
        audioData.push(new Float32Array(e.inputBuffer.getChannelData(0)));
    };

    input.connect(recorder);
    recorder.connect(audioContext.destination);
};

stopBtn.onclick = async () => {
    stopBtn.disabled = true;
    recordBtn.disabled = true;
    document.getElementById("status").innerText = "Processing...";

    recorder.disconnect();
    audioContext.close();
    mediaStream.getTracks().forEach(track => track.stop());

    // Flatten audio data
    let length = audioData.reduce((sum, arr) => sum + arr.length, 0);
    let buffer = new Float32Array(length);
    let offset = 0;
    for (let i = 0; i < audioData.length; i++) {
        buffer.set(audioData[i], offset);
        offset += audioData[i].length;
    }

    // Convert float32 to 16-bit PCM WAV
    function encodeWAV(samples, sampleRate = 22050) {
        const buffer = new ArrayBuffer(44 + samples.length * 2);
        const view = new DataView(buffer);

        function writeString(view, offset, string) {
            for (let i = 0; i < string.length; i++) {
                view.setUint8(offset + i, string.charCodeAt(i));
            }
        }

        // RIFF header
        writeString(view, 0, 'RIFF');
        view.setUint32(4, 36 + samples.length * 2, true);
        writeString(view, 8, 'WAVE');

        // fmt chunk
        writeString(view, 12, 'fmt ');
        view.setUint32(16, 16, true); // chunk size
        view.setUint16(20, 1, true);  // PCM format
        view.setUint16(22, 1, true);  // channels
        view.setUint32(24, sampleRate, true); 
        view.setUint32(28, sampleRate * 2, true); 
        view.setUint16(32, 2, true);  // block align
        view.setUint16(34, 16, true); // bits per sample

        // data chunk
        writeString(view, 36, 'data');
        view.setUint32(40, samples.length * 2, true);

        // PCM samples
        let offset = 44;
        for (let i = 0; i < samples.length; i++, offset += 2) {
            let s = Math.max(-1, Math.min(1, samples[i]));
            view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
        }

        return new Blob([view], { type: 'audio/wav' });
    }

    let wavBlob = encodeWAV(buffer);

    // Send to Flask
    let formData = new FormData();
    formData.append("audio", wavBlob, "voice.wav");

    try {
        let response = await fetch("/predict", { method: "POST", body: formData });
        let result = await response.json();
        document.getElementById("result").innerText =
            result.gender ? "Predicted Gender: " + result.gender : "Error: " + result.error;
    } catch (err) {
        document.getElementById("result").innerText = "Error: " + err;
    }

    document.getElementById("status").innerText = "";
    recordBtn.disabled = false;
};
