from flask import Flask, request, jsonify, render_template
import numpy as np
import librosa
import joblib
import json
from scipy.stats import skew, kurtosis

app = Flask(__name__)

# Load model & feature order
model = joblib.load("gender_rf_model.pkl")
feature_order = json.load(open("feature_order.json"))
fs = 22050

def extract_features(file_path):
    y, sr = librosa.load(file_path, sr=fs)
    features = {}

    # Spectral
    features["mean_spectral_centroid"] = np.mean(librosa.feature.spectral_centroid(y=y, sr=sr))
    features["std_spectral_centroid"] = np.std(librosa.feature.spectral_centroid(y=y, sr=sr))
    features["mean_spectral_bandwidth"] = np.mean(librosa.feature.spectral_bandwidth(y=y, sr=sr))
    features["std_spectral_bandwidth"] = np.std(librosa.feature.spectral_bandwidth(y=y, sr=sr))
    spectral_contrast = librosa.feature.spectral_contrast(y=y, sr=sr)
    features["mean_spectral_contrast"] = np.mean(spectral_contrast)
    features["mean_spectral_flatness"] = np.mean(librosa.feature.spectral_flatness(y=y))
    features["mean_spectral_rolloff"] = np.mean(librosa.feature.spectral_rolloff(y=y, sr=sr))
    features["zero_crossing_rate"] = np.mean(librosa.feature.zero_crossing_rate(y))
    features["rms_energy"] = np.mean(librosa.feature.rms(y=y))

    # Pitch
    pitch, _, _ = librosa.pyin(y, fmin=80, fmax=300)
    pitch = pitch[~np.isnan(pitch)]
    if len(pitch) == 0:
        features["mean_pitch"] = 0
        features["min_pitch"] = 0
        features["max_pitch"] = 0
        features["std_pitch"] = 0
    else:
        features["mean_pitch"] = np.mean(pitch)
        features["min_pitch"] = np.min(pitch)
        features["max_pitch"] = np.max(pitch)
        features["std_pitch"] = np.std(pitch)

    # Spectral shape
    S = np.abs(librosa.stft(y))
    features["spectral_skew"] = skew(S.flatten())
    features["spectral_kurtosis"] = kurtosis(S.flatten())

    # Energy
    features["energy_entropy"] = -np.sum((S / S.sum()) * np.log((S / S.sum()) + 1e-10))
    features["log_energy"] = np.log(np.sum(y ** 2) + 1e-10)

    # MFCCs
    mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
    for i in range(13):
        features[f"mfcc_{i+1}_mean"] = np.mean(mfccs[i])
        features[f"mfcc_{i+1}_std"] = np.std(mfccs[i])

    feature_array = np.array([features[f] for f in feature_order]).reshape(1, -1)
    return feature_array

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    try:
        if "audio" not in request.files:
            return jsonify({"error": "No audio file provided"}), 400

        audio_file = request.files["audio"]
        audio_file.save("uploaded.wav")

        features = extract_features("uploaded.wav")
        pred = model.predict(features)[0]
        label = "Female" if pred == 0 else "Male"

        return jsonify({"gender": label})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
